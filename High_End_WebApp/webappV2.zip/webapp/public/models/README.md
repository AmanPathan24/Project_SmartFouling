# ML Models Directory

This directory contains your trained machine learning models for biofouling detection.

## Supported Model Formats

### ONNX Models (.onnx)
Place your ONNX model files here:
- `biofouling-detector-v1.onnx` - Main detection model
- `marine-vision-v2.onnx` - Alternative model

### TensorFlow.js Models (.json + .bin)
Place your TensorFlow.js models here:
- `marine-vision-v2.json` - Model architecture
- `marine-vision-v2_weights.bin` - Model weights

### PyTorch Models
For PyTorch models, you'll need to:
1. Set up a separate Python API service
2. Update the model loading code to call your API
3. Configure the model path to point to your API endpoint

## Model Requirements

Your models should:
- Accept RGB images as input
- Output bounding boxes, class predictions, and confidence scores
- Support the following biofouling classes:
  - Barnacles
  - Algae (various types)
  - Mussels
  - Hydroids
  - Tube Worms
  - Sea Squirts
  - Bryozoans

## Adding Your Model

1. Copy your model files to this directory
2. Update `src/ml-service.ts` with your model configuration
3. Implement the model-specific loading and inference code
4. Test with your model using the webapp interface

## Demo Mode

Currently, the system runs in demo mode with simulated ML results. To switch to your real model:

1. Replace the simulated code in `ml-service.ts`
2. Add your actual model files here
3. Install the required ML framework dependencies
4. Update the model configuration

See `ML_INTEGRATION_GUIDE.md` for detailed integration instructions.