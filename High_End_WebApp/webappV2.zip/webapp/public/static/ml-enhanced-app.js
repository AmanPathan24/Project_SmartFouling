// Enhanced Marine Biofouling Detection System with ML Integration
// This extends the base app with ML-specific features

class MLEnhancedBiofoulingApp extends BiofoulingApp {
    constructor() {
        super();
        this.selectedModel = 'biofouling-detector-v1';
        this.confidenceThreshold = 0.5;
        this.modelInfo = null;
        this.availableModels = [];
        this.initMLFeatures();
    }

    async initMLFeatures() {
        await this.loadAvailableModels();
        this.setupMLEventListeners();
        await this.updateModelStatus();
    }

    setupMLEventListeners() {
        // Model selection change
        const modelSelect = document.getElementById('model-select');
        if (modelSelect) {
            modelSelect.addEventListener('change', async (e) => {
                this.selectedModel = e.target.value;
                await this.updateModelStatus();
                this.showToast(`Switched to ${this.selectedModel}`, 'info');
            });
        }

        // Confidence threshold slider
        const confidenceSlider = document.getElementById('confidence-slider');
        const confidenceValue = document.getElementById('confidence-value');
        
        if (confidenceSlider && confidenceValue) {
            confidenceSlider.addEventListener('input', (e) => {
                this.confidenceThreshold = parseFloat(e.target.value);
                confidenceValue.textContent = this.confidenceThreshold.toFixed(1);
            });

            confidenceSlider.addEventListener('change', async (e) => {
                await this.updateModelConfig();
                this.showToast(`Confidence threshold updated to ${this.confidenceThreshold}`, 'success');
            });
        }
    }

    async loadAvailableModels() {
        try {
            const response = await axios.get('/api/ml/models');
            this.availableModels = response.data.models;
            
            // Update model select options
            const modelSelect = document.getElementById('model-select');
            if (modelSelect && this.availableModels.length > 0) {
                modelSelect.innerHTML = this.availableModels.map(model => 
                    `<option value="${model.name}">${this.formatModelName(model)}</option>`
                ).join('');
                
                this.selectedModel = this.availableModels[0].name;
            }
        } catch (error) {
            console.error('Failed to load available models:', error);
            this.showError('Failed to load ML models');
        }
    }

    formatModelName(model) {
        const typeLabels = {
            'tensorflow': 'TensorFlow.js',
            'onnx': 'ONNX',
            'pytorch': 'PyTorch'
        };
        
        const displayName = model.name
            .replace(/[-_]/g, ' ')
            .replace(/\b\w/g, l => l.toUpperCase());
            
        return `${displayName} (${typeLabels[model.modelType] || model.modelType})`;
    }

    async updateModelStatus() {
        try {
            const response = await axios.get(`/api/ml/status/${this.selectedModel}`);
            this.modelInfo = response.data.status;
            
            const statusEl = document.getElementById('model-status');
            const classesEl = document.getElementById('model-classes');
            const processingTimeEl = document.getElementById('processing-time');
            
            if (statusEl) {
                if (this.modelInfo.isLoaded) {
                    statusEl.textContent = 'Ready';
                    statusEl.className = 'text-green-400';
                } else {
                    statusEl.textContent = 'Loading...';
                    statusEl.className = 'text-yellow-400';
                }
            }
            
            if (classesEl && this.modelInfo.classes) {
                classesEl.textContent = `${this.modelInfo.classes.length} species`;
            }
            
            if (processingTimeEl) {
                const estimatedTime = this.modelInfo.inputSize ? 
                    (this.modelInfo.inputSize.width * this.modelInfo.inputSize.height / 200000) : 2.3;
                processingTimeEl.textContent = `~${estimatedTime.toFixed(1)}s`;
            }
            
            // Update confidence slider
            const confidenceSlider = document.getElementById('confidence-slider');
            const confidenceValue = document.getElementById('confidence-value');
            
            if (confidenceSlider && this.modelInfo.confidenceThreshold) {
                confidenceSlider.value = this.modelInfo.confidenceThreshold;
                this.confidenceThreshold = this.modelInfo.confidenceThreshold;
                if (confidenceValue) {
                    confidenceValue.textContent = this.confidenceThreshold.toFixed(1);
                }
            }
            
        } catch (error) {
            console.error('Failed to get model status:', error);
            const statusEl = document.getElementById('model-status');
            if (statusEl) {
                statusEl.textContent = 'Error';
                statusEl.className = 'text-red-400';
            }
        }
    }

    async updateModelConfig() {
        try {
            await axios.post(`/api/ml/config/${this.selectedModel}`, {
                confidenceThreshold: this.confidenceThreshold
            });
        } catch (error) {
            console.error('Failed to update model config:', error);
            this.showError('Failed to update model configuration');
        }
    }

    // Override the startAnalysis method to include ML parameters
    async startAnalysis() {
        const sessionName = document.getElementById('session-name').value.trim();
        
        if (!sessionName || this.uploadedFiles.length === 0) {
            this.showError('Please provide a session name and select images');
            return;
        }

        // Show ML-specific loading messages
        this.showMLLoadingSequence();

        try {
            // Create session
            const sessionResponse = await axios.post('/api/sessions', {
                sessionName: sessionName
            });

            if (!sessionResponse.data || !sessionResponse.data.sessionId) {
                throw new Error('Invalid session response');
            }

            const sessionId = sessionResponse.data.sessionId;
            this.updateMLProgress('Uploading images...', 30);

            // Upload files
            const formData = new FormData();
            this.uploadedFiles.forEach(file => {
                formData.append('images', file);
            });

            const uploadResponse = await axios.post(`/api/sessions/${sessionId}/upload`, formData, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                },
                onUploadProgress: (progressEvent) => {
                    const percentCompleted = Math.round((progressEvent.loaded * 100) / progressEvent.total);
                    const progress = 30 + (percentCompleted * 0.3); // 30-60% for upload
                    this.updateMLProgress(`Uploading images... ${percentCompleted}%`, progress);
                }
            });

            if (!uploadResponse.data) {
                throw new Error('Upload failed');
            }

            this.updateMLProgress('Loading ML model...', 65);

            // Start ML analysis with selected model and confidence threshold
            const analysisResponse = await axios.post(`/api/sessions/${sessionId}/analyze?model=${this.selectedModel}`, {
                confidenceThreshold: this.confidenceThreshold
            });

            this.updateMLProgress('Processing with AI...', 90);

            // Show ML results summary
            if (analysisResponse.data.results) {
                this.showMLResults(analysisResponse.data.results);
            }

            // Reload sessions and show results
            await this.loadSessions();
            await this.loadSessionDetails(sessionId);

            this.hideLoading();
            this.showSuccess(`ML analysis completed! Found ${analysisResponse.data.results?.totalDetections || 0} detections`);
            
            // Clear form
            this.uploadedFiles = [];
            document.getElementById('session-name').value = '';
            document.getElementById('file-list').innerHTML = '';
            this.updateUploadButton();

            // Switch to results tab
            document.querySelector('[data-tab="results"]').click();

        } catch (error) {
            this.hideLoading();
            console.error('ML analysis failed:', error);
            
            let errorMessage = 'ML analysis failed. ';
            if (error.response?.data?.details) {
                errorMessage += error.response.data.details;
            } else if (error.response) {
                errorMessage += error.response.data?.error || `Server error (${error.response.status})`;
            } else if (error.request) {
                errorMessage += 'Could not connect to ML service.';
            } else {
                errorMessage += error.message || 'Please try again.';
            }
            
            this.showError(errorMessage);
        }
    }

    showMLLoadingSequence() {
        const modal = document.getElementById('loading-modal');
        const progressText = document.getElementById('progress-text');
        
        modal.classList.remove('hidden');
        modal.classList.add('flex');
        
        // Update the loading modal with ML-specific content
        const modalContent = modal.querySelector('.glass-card');
        if (modalContent) {
            modalContent.innerHTML = `
                <div class="relative mb-8">
                    <div class="absolute inset-0 bg-gradient-to-r from-purple-400 to-blue-500 rounded-full blur-2xl opacity-50 animate-pulse"></div>
                    <div class="animate-spin rounded-full h-20 w-20 border-4 border-transparent border-t-purple-400 border-r-blue-500 mx-auto relative z-10"></div>
                </div>
                <h3 class="text-2xl font-bold gradient-text mb-3">
                    <i class="fas fa-brain mr-2"></i>AI Processing
                </h3>
                <p class="text-gray-300 text-lg mb-2" id="ml-progress-text">Initializing ML pipeline...</p>
                <p class="text-sm text-purple-400 mb-4">Model: ${this.selectedModel}</p>
                <div class="progress-bar mb-2">
                    <div class="progress-fill bg-gradient-to-r from-purple-500 to-blue-500" style="width: 0%" id="progress-fill"></div>
                </div>
                <div class="grid grid-cols-2 gap-4 mt-6 text-xs">
                    <div class="text-center">
                        <i class="fas fa-microchip text-purple-400 mb-1 block"></i>
                        <span class="text-gray-400">Confidence: ${(this.confidenceThreshold * 100).toFixed(0)}%</span>
                    </div>
                    <div class="text-center">
                        <i class="fas fa-eye text-blue-400 mb-1 block"></i>
                        <span class="text-gray-400">${this.modelInfo?.classes?.length || 7} Classes</span>
                    </div>
                </div>
            `;
        }
    }

    updateMLProgress(message, progress) {
        const progressFill = document.getElementById('progress-fill');
        const progressText = document.getElementById('ml-progress-text') || document.getElementById('progress-text');
        
        if (progressFill) {
            progressFill.style.width = `${progress}%`;
        }
        
        if (progressText) {
            progressText.textContent = message;
        }
    }

    showMLResults(results) {
        const toast = document.createElement('div');
        toast.className = 'toast-notification fixed top-4 right-4 glass-card p-6 max-w-md z-50 fade-in border border-purple-500/30 bg-gradient-to-r from-purple-500/10 to-blue-500/10';
        
        toast.innerHTML = `
            <div class="flex items-start space-x-4">
                <div class="relative">
                    <div class="absolute inset-0 bg-gradient-to-r from-purple-400 to-blue-500 rounded-full blur-lg opacity-50"></div>
                    <i class="fas fa-brain text-2xl text-white relative z-10"></i>
                </div>
                <div class="flex-1">
                    <h4 class="font-bold text-lg gradient-text mb-2">Analysis Complete!</h4>
                    <div class="space-y-2 text-sm">
                        <div class="flex justify-between">
                            <span class="text-gray-300">Detections:</span>
                            <span class="text-blue-400 font-medium">${results.totalDetections}</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-300">Coverage:</span>
                            <span class="text-orange-400 font-medium">${results.totalCoverage.toFixed(1)}%</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-300">Dominant:</span>
                            <span class="text-green-400 font-medium">${results.dominantSpecies}</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-300">Time:</span>
                            <span class="text-purple-400 font-medium">${(results.avgProcessingTime / 1000).toFixed(1)}s</span>
                        </div>
                    </div>
                </div>
                <button onclick="this.closest('.toast-notification').remove()" class="text-gray-400 hover:text-white">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `;
        
        document.body.appendChild(toast);
        
        setTimeout(() => {
            if (toast && toast.parentElement) {
                toast.style.animation = 'fadeOut 0.3s ease-out';
                setTimeout(() => {
                    if (toast && toast.parentElement) {
                        toast.remove();
                    }
                }, 300);
            }
        }, 8000);
    }

    // Override renderResults to show ML-specific information
    renderResults() {
        super.renderResults();
        
        // Add ML-specific enhancements if we have ML results
        if (this.currentSession && this.currentSession.session) {
            this.addMLResultsEnhancements();
        }
    }

    addMLResultsEnhancements() {
        const container = document.getElementById('results-content');
        if (!container || !this.currentSession) return;

        // Add ML model information badge
        const sessionHeader = container.querySelector('.bg-slate-800\\/50');
        if (sessionHeader) {
            const mlBadge = document.createElement('div');
            mlBadge.className = 'mt-4 flex items-center space-x-4 text-sm';
            mlBadge.innerHTML = `
                <div class="flex items-center space-x-2 px-3 py-2 glass rounded-lg border border-purple-500/30">
                    <i class="fas fa-brain text-purple-400"></i>
                    <span class="text-gray-300">ML Model:</span>
                    <span class="text-purple-400 font-medium">${this.selectedModel || 'Default'}</span>
                </div>
                ${this.currentSession.analytics?.avg_confidence ? `
                <div class="flex items-center space-x-2 px-3 py-2 glass rounded-lg border border-blue-500/30">
                    <i class="fas fa-percentage text-blue-400"></i>
                    <span class="text-gray-300">Avg Confidence:</span>
                    <span class="text-blue-400 font-medium">${(this.currentSession.analytics.avg_confidence * 100).toFixed(1)}%</span>
                </div>
                ` : ''}
                ${this.currentSession.analytics?.processing_time_ms ? `
                <div class="flex items-center space-x-2 px-3 py-2 glass rounded-lg border border-yellow-500/30">
                    <i class="fas fa-clock text-yellow-400"></i>
                    <span class="text-gray-300">Processing:</span>
                    <span class="text-yellow-400 font-medium">${(this.currentSession.analytics.processing_time_ms / 1000).toFixed(1)}s</span>
                </div>
                ` : ''}
            `;
            sessionHeader.appendChild(mlBadge);
        }
    }
}

// Initialize enhanced ML application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    // Replace the basic app with the ML-enhanced version
    window.biofoulingApp = new MLEnhancedBiofoulingApp();
});