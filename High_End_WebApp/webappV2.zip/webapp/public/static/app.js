// Marine Biofouling Detection System - Frontend Application

class BiofoulingApp {
    constructor() {
        this.currentSession = null;
        this.uploadedFiles = [];
        this.sessions = [];
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadSessions();
        this.setupTabNavigation();
        this.initializeCharts();
        this.init3DVisualization();
    }

    setupEventListeners() {
        // File upload
        const fileInput = document.getElementById('file-input');
        const dropZone = document.getElementById('drop-zone');
        const uploadBtn = document.getElementById('upload-btn');
        const newSessionBtn = document.getElementById('new-session-btn');

        fileInput.addEventListener('change', (e) => this.handleFiles(e.target.files));
        
        dropZone.addEventListener('click', () => fileInput.click());
        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropZone.classList.add('drop-zone-active');
        });
        dropZone.addEventListener('dragleave', (e) => {
            e.preventDefault();
            // Only remove if we're leaving the dropZone itself, not a child
            if (!dropZone.contains(e.relatedTarget)) {
                dropZone.classList.remove('drop-zone-active');
            }
        });
        dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropZone.classList.remove('drop-zone-active');
            
            // Add files with visual feedback
            const files = Array.from(e.dataTransfer.files);
            this.handleFiles(files);
            
            // Show success message
            this.showToast(`Added ${files.length} file(s) for analysis`, 'success');
        });

        uploadBtn.addEventListener('click', () => this.startAnalysis());
        newSessionBtn.addEventListener('click', () => this.createNewSession());
    }

    setupTabNavigation() {
        const tabButtons = document.querySelectorAll('.tab-button');
        const tabContents = document.querySelectorAll('.tab-content');

        tabButtons.forEach(button => {
            button.addEventListener('click', () => {
                const tabName = button.dataset.tab;
                
                // Update button states
                tabButtons.forEach(btn => {
                    btn.classList.remove('tab-active');
                    btn.classList.add('tab-inactive');
                });
                button.classList.remove('tab-inactive');
                button.classList.add('tab-active');

                // Show/hide content
                tabContents.forEach(content => {
                    content.classList.add('hidden');
                });
                document.getElementById(`tab-${tabName}`).classList.remove('hidden');

                // Load tab-specific content
                if (tabName === 'analytics') {
                    this.updateCharts();
                } else if (tabName === '3d-viz') {
                    this.render3D();
                }
            });
        });
    }

    async loadSessions() {
        try {
            const response = await axios.get('/api/sessions');
            if (response.data) {
                this.sessions = Array.isArray(response.data) ? response.data : [];
                this.renderSessions();
            } else {
                this.sessions = [];
                this.renderSessions();
            }
        } catch (error) {
            console.error('Failed to load sessions:', error);
            // Check if it's a network error or server error
            if (error.response) {
                // Server responded with error status
                this.showError(`Failed to load sessions: ${error.response.data?.error || 'Server error'}`);
            } else if (error.request) {
                // Request was made but no response
                this.showError('Failed to connect to server. Please check your connection.');
            } else {
                // Something else happened
                this.showError('Failed to load sessions. Please try again.');
            }
            this.sessions = [];
            this.renderSessions();
        }
    }

    renderSessions() {
        const container = document.getElementById('recent-sessions');
        
        if (this.sessions.length === 0) {
            container.innerHTML = `
                <div class="text-center text-slate-400 py-8">
                    <i class="fas fa-plus-circle text-2xl mb-2"></i>
                    <p>No sessions yet. Create your first analysis!</p>
                </div>
            `;
            return;
        }

        container.innerHTML = this.sessions.map((session, index) => {
            // Validate session data
            const sessionName = session.session_name || 'Unnamed Session';
            const createdAt = session.created_at ? new Date(session.created_at) : new Date();
            const status = session.status || 'pending';
            const imageCount = session.image_count || 0;
            const sessionId = session.id || index;
            
            return `
            <div class="session-card p-6 mb-4 fade-in" style="animation-delay: ${index * 0.1}s" onclick="window.biofoulingApp.loadSessionDetails(${sessionId})">
                <div class="flex justify-between items-start mb-4">
                    <div>
                        <h3 class="font-bold text-lg text-white mb-1">${this.escapeHtml(sessionName)}</h3>
                        <p class="text-sm text-gray-400">${createdAt.toLocaleDateString('en-US', { 
                            year: 'numeric', month: 'short', day: 'numeric', 
                            hour: '2-digit', minute: '2-digit' 
                        })}</p>
                    </div>
                    <span class="status-badge ${
                        status === 'completed' ? 'status-success' :
                        status === 'processing' ? 'status-processing' :
                        status === 'failed' ? 'status-error' :
                        'status-processing'
                    }">
                        ${status}
                    </span>
                </div>
                <div class="flex items-center justify-between">
                    <div class="flex items-center space-x-4 text-sm text-gray-300">
                        <span class="flex items-center">
                            <i class="fas fa-images mr-2 text-blue-400"></i>
                            ${imageCount} image${imageCount !== 1 ? 's' : ''}
                        </span>
                        ${status === 'completed' ? `
                            <span class="flex items-center">
                                <i class="fas fa-check-circle mr-2 text-green-400"></i>
                                Analysis complete
                            </span>
                        ` : ''}
                    </div>
                    <i class="fas fa-chevron-right text-gray-400"></i>
                </div>
            </div>
        `}).join('');

        // Add click handlers
        document.querySelectorAll('.session-item').forEach(item => {
            item.addEventListener('click', () => {
                this.loadSessionDetails(item.dataset.id);
            });
        });
    }

    getStatusColor(status) {
        const colors = {
            'pending': 'bg-yellow-600 text-yellow-100',
            'processing': 'bg-blue-600 text-blue-100',
            'completed': 'bg-green-600 text-green-100',
            'failed': 'bg-red-600 text-red-100'
        };
        return colors[status] || 'bg-gray-600 text-gray-100';
    }

    async loadSessionDetails(sessionId) {
        try {
            const response = await axios.get(`/api/sessions/${sessionId}`);
            if (!response.data) {
                throw new Error('No session data received');
            }
            
            this.currentSession = response.data;
            // Ensure we have the expected structure
            if (!this.currentSession.session) {
                this.currentSession.session = { session_name: 'Unknown Session', updated_at: new Date().toISOString() };
            }
            if (!this.currentSession.images) {
                this.currentSession.images = [];
            }
            if (!this.currentSession.results) {
                this.currentSession.results = [];
            }
            
            this.renderResults();
            
            // Switch to results tab
            const resultsTab = document.querySelector('[data-tab="results"]');
            if (resultsTab) {
                resultsTab.click();
            }
        } catch (error) {
            console.error('Failed to load session details:', error);
            let errorMessage = 'Failed to load session details. ';
            if (error.response) {
                errorMessage += error.response.data?.error || 'Server error occurred.';
            } else if (error.request) {
                errorMessage += 'Could not connect to server.';
            } else {
                errorMessage += error.message || 'Please try again.';
            }
            this.showError(errorMessage);
            this.currentSession = null;
            this.renderResults();
        }
    }

    // Add HTML escaping helper method
    escapeHtml(text) {
        const map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return text ? text.toString().replace(/[&<>"']/g, m => map[m]) : '';
    }
    
    renderResults() {
        const container = document.getElementById('results-content');
        if (!container) {
            console.error('Results container not found');
            return;
        }
        
        const session = this.currentSession;

        if (!session) {
            container.innerHTML = `
                <div class="text-center text-slate-400 py-16">
                    <i class="fas fa-search text-4xl mb-4"></i>
                    <p class="text-lg">Select a session to view results</p>
                </div>
            `;
            return;
        }

        container.innerHTML = `
            <div class="space-y-8">
                <!-- Session Header -->
                <div class="bg-slate-800/50 rounded-xl p-6">
                    <div class="flex justify-between items-start mb-4">
                        <div>
                            <h2 class="text-2xl font-bold">${session.session.session_name}</h2>
                            <p class="text-slate-400">Analysis completed on ${new Date(session.session.updated_at).toLocaleDateString()}</p>
                        </div>
                        <div class="text-right">
                            <div class="text-3xl font-bold text-blue-400">${session.analytics?.total_coverage_percentage?.toFixed(1) || '0'}%</div>
                            <p class="text-sm text-slate-400">Total Coverage</p>
                        </div>
                    </div>
                    
                    ${session.analytics ? `
                        <div class="grid md:grid-cols-3 gap-4 mt-6">
                            <div class="bg-slate-700/50 rounded-lg p-4 text-center">
                                <div class="text-lg font-semibold text-orange-400">$${session.analytics.fuel_cost_impact?.toFixed(2) || '0'}</div>
                                <p class="text-sm text-slate-400">Estimated Fuel Cost Impact</p>
                            </div>
                            <div class="bg-slate-700/50 rounded-lg p-4 text-center">
                                <div class="text-lg font-semibold text-red-400">$${session.analytics.maintenance_cost?.toFixed(2) || '0'}</div>
                                <p class="text-sm text-slate-400">Cleaning Cost</p>
                            </div>
                            <div class="bg-slate-700/50 rounded-lg p-4 text-center">
                                <div class="text-lg font-semibold ${this.getUrgencyColor(session.analytics.cleaning_urgency)}">${session.analytics.cleaning_urgency || 'N/A'}</div>
                                <p class="text-sm text-slate-400">Cleaning Urgency</p>
                            </div>
                        </div>
                    ` : ''}
                </div>

                <!-- Images and Detections -->
                <div class="grid lg:grid-cols-2 gap-6">
                    ${session.images.map((image, index) => `
                        <div class="bg-slate-800/50 rounded-xl p-6">
                            <h3 class="text-lg font-semibold mb-4">${image.filename}</h3>
                            
                            <!-- Image Comparison Slider -->
                            <div class="comparison-slider mb-6" style="height: 300px;">
                                <img src="${image.original_url}" alt="Original" class="w-full h-full object-cover rounded-lg">
                                <div class="comparison-overlay bg-slate-900" style="width: 50%;">
                                    <img src="${image.preprocessed_url || image.original_url}" alt="Processed" class="w-full h-full object-cover rounded-lg">
                                </div>
                                <input type="range" min="0" max="100" value="50" class="w-full mt-2 comparison-range" data-index="${index}">
                            </div>
                            
                            <!-- Species Detections -->
                            <div class="space-y-3">
                                <h4 class="font-medium">Detected Species:</h4>
                                ${this.getImageDetections(image.id).map(detection => `
                                    <div class="flex justify-between items-center bg-slate-700/50 rounded-lg p-3">
                                        <div>
                                            <div class="font-medium">${detection.species_name}</div>
                                            <div class="text-sm text-slate-400">${detection.scientific_name || 'Scientific name not available'}</div>
                                        </div>
                                        <div class="text-right">
                                            <div class="text-lg font-semibold text-blue-400">${detection.coverage_percentage.toFixed(1)}%</div>
                                            <div class="text-sm text-slate-400">${(detection.confidence_score * 100).toFixed(1)}% confidence</div>
                                        </div>
                                    </div>
                                `).join('')}
                            </div>
                        </div>
                    `).join('')}
                </div>

                <!-- Species Information -->
                ${session.detections.length > 0 ? `
                    <div class="bg-slate-800/50 rounded-xl p-6">
                        <h3 class="text-lg font-semibold mb-4">Species Information & Recommendations</h3>
                        <div class="grid gap-4">
                            ${this.getUniqueSpecies(session.detections).map(species => `
                                <div class="bg-slate-700/50 rounded-lg p-4">
                                    <div class="flex justify-between items-start mb-3">
                                        <h4 class="font-medium text-lg">${species.species_name}</h4>
                                        <span class="px-2 py-1 text-xs rounded-full ${this.getImpactColor(species.impact_level)}">
                                            ${species.impact_level} impact
                                        </span>
                                    </div>
                                    <p class="text-slate-300 mb-3">${species.description || 'No description available'}</p>
                                    <div class="bg-blue-900/30 rounded-lg p-3">
                                        <h5 class="font-medium text-blue-300 mb-2">Recommended Actions:</h5>
                                        <p class="text-sm text-slate-300">${species.recommended_actions || 'Consult marine maintenance specialist'}</p>
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                ` : ''}
            </div>
        `;

        // Setup comparison sliders
        document.querySelectorAll('.comparison-range').forEach(slider => {
            slider.addEventListener('input', (e) => {
                const overlay = e.target.closest('.bg-slate-800\\/50').querySelector('.comparison-overlay');
                overlay.style.width = e.target.value + '%';
            });
        });
    }

    getImageDetections(imageId) {
        return this.currentSession.detections.filter(d => d.image_id === imageId);
    }

    getUniqueSpecies(detections) {
        const speciesMap = new Map();
        detections.forEach(detection => {
            if (!speciesMap.has(detection.species_name)) {
                speciesMap.set(detection.species_name, detection);
            }
        });
        return Array.from(speciesMap.values());
    }

    getUrgencyColor(urgency) {
        const colors = {
            'low': 'text-green-400',
            'medium': 'text-yellow-400',
            'high': 'text-orange-400',
            'critical': 'text-red-400'
        };
        return colors[urgency] || 'text-gray-400';
    }

    getImpactColor(impact) {
        const colors = {
            'low': 'bg-green-600 text-green-100',
            'medium': 'bg-yellow-600 text-yellow-100',
            'high': 'bg-orange-600 text-orange-100',
            'critical': 'bg-red-600 text-red-100'
        };
        return colors[impact] || 'bg-gray-600 text-gray-100';
    }

    handleFiles(files) {
        // If files is already an array (from removeFile), use it directly
        if (!Array.isArray(files)) {
            files = Array.from(files);
        }
        
        // Filter for valid image files
        const validFiles = files.filter(file => {
            if (!file.type || !file.type.startsWith('image/')) {
                this.showError(`${file.name} is not a valid image file`);
                return false;
            }
            // Check file size (max 10MB)
            if (file.size > 10 * 1024 * 1024) {
                this.showError(`${file.name} is too large (max 10MB)`);
                return false;
            }
            return true;
        });
        
        this.uploadedFiles = validFiles;
        const fileList = document.getElementById('file-list');
        const uploadBtn = document.getElementById('upload-btn');
        
        fileList.innerHTML = '';
        
        this.uploadedFiles.forEach((file, index) => {
            const fileItem = document.createElement('div');
            fileItem.className = 'file-item flex items-center justify-between p-4 fade-in';
            fileItem.style.animationDelay = `${index * 0.1}s`;
            
            fileItem.innerHTML = `
                <div class="flex items-center space-x-4">
                    <div class="file-preview w-12 h-12 rounded-lg loading-skeleton bg-cover bg-center" id="preview-${index}"></div>
                    <div>
                        <p class="font-semibold text-white">${file.name}</p>
                        <p class="text-sm text-gray-400">${this.formatFileSize(file.size)} • ${file.type.split('/')[1].toUpperCase()}</p>
                    </div>
                </div>
                <div class="flex items-center space-x-2">
                    <span class="status-badge status-success">Ready</span>
                    <button onclick="window.biofoulingApp.removeFile(${index})" class="glass-button p-2 text-red-400 hover:text-red-300">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            `;
            fileList.appendChild(fileItem);
            
            // Create image preview
            const reader = new FileReader();
            reader.onload = (e) => {
                const preview = document.getElementById(`preview-${index}`);
                if (preview) {
                    preview.style.backgroundImage = `url(${e.target.result})`;
                    preview.classList.remove('loading-skeleton');
                }
            };
            reader.onerror = () => {
                this.showError(`Failed to read ${file.name}`);
            };
            reader.readAsDataURL(file);
        });
        
        // Update upload button state
        this.updateUploadButton();
        
        // Add visual feedback
        if (this.uploadedFiles.length > 0) {
            uploadBtn.innerHTML = `<i class="fas fa-rocket mr-3"></i>Start AI Analysis (${this.uploadedFiles.length} file${this.uploadedFiles.length > 1 ? 's' : ''})`;
            uploadBtn.classList.add('glow');
        } else {
            uploadBtn.innerHTML = `<i class="fas fa-rocket mr-3"></i>Start AI Analysis`;
            uploadBtn.classList.remove('glow');
        }
    }
    
    formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
    }

    renderFileList() {
        const container = document.getElementById('file-list');
        
        if (this.uploadedFiles.length === 0) {
            container.innerHTML = '';
            return;
        }

        container.innerHTML = `
            <div class="bg-slate-700 rounded-lg p-4">
                <h4 class="font-medium mb-3">Selected Images (${this.uploadedFiles.length})</h4>
                <div class="space-y-2 max-h-32 overflow-y-auto">
                    ${this.uploadedFiles.map((file, index) => `
                        <div class="flex justify-between items-center text-sm">
                            <span class="truncate">${file.name}</span>
                            <span class="text-slate-400">${(file.size / 1024 / 1024).toFixed(1)} MB</span>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }

    updateUploadButton() {
        const uploadBtn = document.getElementById('upload-btn');
        const sessionName = document.getElementById('session-name').value.trim();
        
        uploadBtn.disabled = this.uploadedFiles.length === 0 || !sessionName;
    }

    async createNewSession() {
        const sessionName = prompt('Enter session name:', 'Hull Inspection - ' + new Date().toLocaleDateString());
        if (!sessionName) return;

        document.getElementById('session-name').value = sessionName;
        document.querySelector('[data-tab="upload"]').click();
    }

    async startAnalysis() {
        const sessionName = document.getElementById('session-name').value.trim();
        
        if (!sessionName || this.uploadedFiles.length === 0) {
            this.showError('Please provide a session name and select images');
            return;
        }

        this.showLoading('Creating session...', 10);

        try {
            // Create session
            const sessionResponse = await axios.post('/api/sessions', {
                sessionName: sessionName
            });

            if (!sessionResponse.data || !sessionResponse.data.sessionId) {
                throw new Error('Invalid session response');
            }

            const sessionId = sessionResponse.data.sessionId;
            this.showLoading('Uploading images...', 30);

            // Upload files
            const formData = new FormData();
            this.uploadedFiles.forEach(file => {
                formData.append('images', file);
            });

            const uploadResponse = await axios.post(`/api/sessions/${sessionId}/upload`, formData, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                },
                onUploadProgress: (progressEvent) => {
                    const percentCompleted = Math.round((progressEvent.loaded * 100) / progressEvent.total);
                    const progress = 30 + (percentCompleted * 0.4); // 30-70% for upload
                    this.showLoading(`Uploading images... ${percentCompleted}%`, progress);
                }
            });

            if (!uploadResponse.data) {
                throw new Error('Upload failed');
            }

            this.showLoading('Analyzing images with AI...', 75);

            // Start analysis
            await axios.post(`/api/sessions/${sessionId}/analyze`);

            this.showLoading('Finalizing results...', 90);

            // Reload sessions and show results
            await this.loadSessions();
            await this.loadSessionDetails(sessionId);

            this.hideLoading();
            this.showSuccess('Analysis completed successfully!');
            
            // Clear form
            this.uploadedFiles = [];
            document.getElementById('session-name').value = '';
            document.getElementById('file-list').innerHTML = '';
            this.updateUploadButton();

            // Switch to results tab
            document.querySelector('[data-tab="results"]').click();

        } catch (error) {
            this.hideLoading();
            console.error('Analysis failed:', error);
            
            let errorMessage = 'Analysis failed. ';
            if (error.response) {
                // Server error
                errorMessage += error.response.data?.error || `Server error (${error.response.status})`;
            } else if (error.request) {
                // Network error
                errorMessage += 'Could not connect to server.';
            } else {
                // Other error
                errorMessage += error.message || 'Please try again.';
            }
            
            this.showError(errorMessage);
        }
    }

    initializeCharts() {
        // Species Distribution Chart
        const speciesCtx = document.getElementById('species-chart').getContext('2d');
        this.speciesChart = new Chart(speciesCtx, {
            type: 'doughnut',
            data: {
                labels: [],
                datasets: [{
                    data: [],
                    backgroundColor: [
                        '#3b82f6', '#ef4444', '#10b981', '#f59e0b',
                        '#8b5cf6', '#06b6d4', '#f97316'
                    ]
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: { color: '#cbd5e1' }
                    }
                }
            }
        });

        // Cost Analysis Chart
        const costCtx = document.getElementById('cost-chart').getContext('2d');
        this.costChart = new Chart(costCtx, {
            type: 'bar',
            data: {
                labels: ['Fuel Cost Impact', 'Cleaning Cost', 'Total Cost'],
                datasets: [{
                    label: 'Cost ($)',
                    data: [],
                    backgroundColor: ['#f59e0b', '#ef4444', '#8b5cf6']
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: { color: '#cbd5e1' }
                    },
                    x: {
                        ticks: { color: '#cbd5e1' }
                    }
                },
                plugins: {
                    legend: {
                        labels: { color: '#cbd5e1' }
                    }
                }
            }
        });

        // Density Trend Chart
        const densityCtx = document.getElementById('density-chart').getContext('2d');
        this.densityChart = new Chart(densityCtx, {
            type: 'line',
            data: {
                labels: [],
                datasets: [{
                    label: 'Fouling Coverage %',
                    data: [],
                    borderColor: '#3b82f6',
                    backgroundColor: '#3b82f650',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        ticks: { color: '#cbd5e1' }
                    },
                    x: {
                        ticks: { color: '#cbd5e1' }
                    }
                },
                plugins: {
                    legend: {
                        labels: { color: '#cbd5e1' }
                    }
                }
            }
        });
    }

    updateCharts() {
        if (!this.sessions.length) return;

        // Update species distribution
        const speciesData = {};
        this.sessions.forEach(session => {
            if (session.dominant_species) {
                speciesData[session.dominant_species] = (speciesData[session.dominant_species] || 0) + 1;
            }
        });

        this.speciesChart.data.labels = Object.keys(speciesData);
        this.speciesChart.data.datasets[0].data = Object.values(speciesData);
        this.speciesChart.update();

        // Update cost analysis
        const avgFuelCost = this.sessions.reduce((sum, s) => sum + (s.fuel_cost_impact || 0), 0) / this.sessions.length;
        const avgCleaningCost = this.sessions.reduce((sum, s) => sum + (s.maintenance_cost || 0), 0) / this.sessions.length;
        
        this.costChart.data.datasets[0].data = [
            avgFuelCost,
            avgCleaningCost,
            avgFuelCost + avgCleaningCost
        ];
        this.costChart.update();

        // Update density trend
        const sortedSessions = [...this.sessions]
            .filter(s => s.total_coverage_percentage)
            .sort((a, b) => new Date(a.created_at) - new Date(b.created_at));
        
        this.densityChart.data.labels = sortedSessions.map(s => 
            new Date(s.created_at).toLocaleDateString()
        );
        this.densityChart.data.datasets[0].data = sortedSessions.map(s => 
            s.total_coverage_percentage
        );
        this.densityChart.update();
    }

    init3DVisualization() {
        const container = document.getElementById('three-container');
        
        // Scene setup
        this.scene = new THREE.Scene();
        this.camera = new THREE.PerspectiveCamera(75, container.clientWidth / container.clientHeight, 0.1, 1000);
        this.renderer = new THREE.WebGLRenderer({ antialias: true });
        this.renderer.setSize(container.clientWidth, container.clientHeight);
        this.renderer.setClearColor(0x0f172a);
        container.appendChild(this.renderer.domElement);

        // Create ship hull geometry
        const hullGeometry = new THREE.CylinderGeometry(0.8, 1.2, 4, 16);
        const hullMaterial = new THREE.MeshPhongMaterial({ 
            color: 0x64748b,
            transparent: true,
            opacity: 0.8
        });
        this.hull = new THREE.Mesh(hullGeometry, hullMaterial);
        this.hull.rotation.x = Math.PI / 2;
        this.scene.add(this.hull);

        // Add fouling regions
        this.addFoulingRegions();

        // Lighting
        const ambientLight = new THREE.AmbientLight(0x404040, 0.6);
        this.scene.add(ambientLight);
        
        const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
        directionalLight.position.set(5, 5, 5);
        this.scene.add(directionalLight);

        // Position camera
        this.camera.position.set(0, 0, 6);
        this.camera.lookAt(0, 0, 0);

        // Animation controls
        this.setupControls();
        this.render3D();
    }

    addFoulingRegions() {
        const foulingColors = {
            'Barnacles': 0xff6b6b,
            'Algae': 0x51cf66,
            'Mussels': 0x845ef7,
            'Tube Worms': 0xffd43b
        };

        // Add random fouling spots
        for (let i = 0; i < 15; i++) {
            const spotGeometry = new THREE.SphereGeometry(0.1, 8, 8);
            const species = Object.keys(foulingColors)[Math.floor(Math.random() * Object.keys(foulingColors).length)];
            const spotMaterial = new THREE.MeshPhongMaterial({ 
                color: foulingColors[species],
                transparent: true,
                opacity: 0.7
            });
            
            const spot = new THREE.Mesh(spotGeometry, spotMaterial);
            
            // Position on hull surface
            const angle = (Math.PI * 2 * i) / 15;
            const height = (Math.random() - 0.5) * 3.5;
            const radius = 1 + Math.random() * 0.2;
            
            spot.position.set(
                Math.cos(angle) * radius,
                Math.sin(angle) * radius,
                height
            );
            
            this.scene.add(spot);
        }
    }

    setupControls() {
        let mouseDown = false;
        let mouseX = 0;
        let mouseY = 0;

        this.renderer.domElement.addEventListener('mousedown', (event) => {
            mouseDown = true;
            mouseX = event.clientX;
            mouseY = event.clientY;
        });

        document.addEventListener('mouseup', () => {
            mouseDown = false;
        });

        document.addEventListener('mousemove', (event) => {
            if (!mouseDown) return;

            const deltaX = event.clientX - mouseX;
            const deltaY = event.clientY - mouseY;

            this.hull.rotation.z += deltaX * 0.01;
            this.hull.rotation.y += deltaY * 0.01;

            mouseX = event.clientX;
            mouseY = event.clientY;
        });

        // Zoom with mouse wheel
        this.renderer.domElement.addEventListener('wheel', (event) => {
            event.preventDefault();
            this.camera.position.z += event.deltaY * 0.01;
            this.camera.position.z = Math.max(2, Math.min(10, this.camera.position.z));
        });
    }

    render3D() {
        requestAnimationFrame(() => this.render3D());
        
        // Auto-rotate hull slowly
        this.hull.rotation.z += 0.005;
        
        this.renderer.render(this.scene, this.camera);
    }

    showLoading(message = 'Analyzing biofouling patterns...', progress = 0) {
        const modal = document.getElementById('loading-modal');
        const progressFill = document.getElementById('progress-fill');
        const progressText = document.getElementById('progress-text');
        
        modal.classList.remove('hidden');
        modal.classList.add('flex');
        
        // Update progress
        if (progressFill) {
            progressFill.style.width = `${progress}%`;
        }
        
        // Update message
        if (progressText) {
            progressText.textContent = message;
        }
    }

    hideLoading() {
        const modal = document.getElementById('loading-modal');
        modal.classList.add('hidden');
        modal.classList.remove('flex');
    }

    showSuccess(message) {
        this.showToast(message, 'success');
    }

    showError(message) {
        console.error('Error:', message);
        this.showToast(message, 'error');
    }
    
    showToast(message, type = 'info', duration = 3000) {
        // Remove any existing toasts with the same message
        const existingToasts = document.querySelectorAll('.toast-notification');
        existingToasts.forEach(toast => {
            if (toast.textContent.includes(message)) {
                toast.remove();
            }
        });
        
        const toast = document.createElement('div');
        toast.className = `toast-notification fixed top-4 right-4 glass-card p-4 max-w-sm z-50 fade-in`;
        toast.style.minWidth = '300px';
        
        const iconClass = {
            success: 'fas fa-check-circle text-green-400',
            error: 'fas fa-exclamation-circle text-red-400',
            warning: 'fas fa-exclamation-triangle text-yellow-400',
            info: 'fas fa-info-circle text-blue-400'
        }[type] || 'fas fa-info-circle text-blue-400';
        
        const bgClass = {
            success: 'border-green-500/30 bg-green-500/10',
            error: 'border-red-500/30 bg-red-500/10',
            warning: 'border-yellow-500/30 bg-yellow-500/10',
            info: 'border-blue-500/30 bg-blue-500/10'
        }[type] || 'border-blue-500/30 bg-blue-500/10';
        
        toast.classList.add(...bgClass.split(' '));
        
        toast.innerHTML = `
            <div class="flex items-center space-x-3">
                <i class="${iconClass} text-xl"></i>
                <p class="text-white font-medium flex-1">${message}</p>
                <button onclick="this.closest('.toast-notification').remove()" class="text-gray-400 hover:text-white ml-2">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `;
        
        document.body.appendChild(toast);
        
        // Force reflow to ensure animation works
        toast.offsetHeight;
        
        // Auto remove after duration
        setTimeout(() => {
            if (toast && toast.parentElement) {
                toast.style.animation = 'fadeOut 0.3s ease-out';
                setTimeout(() => {
                    if (toast && toast.parentElement) {
                        toast.remove();
                    }
                }, 300);
            }
        }, duration);
    }
    
    // Add the missing removeFile method
    removeFile(index) {
        this.uploadedFiles.splice(index, 1);
        this.handleFiles(this.uploadedFiles);
        this.showToast('File removed', 'info', 2000);
    }
}

// Initialize application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.biofoulingApp = new BiofoulingApp();
});

// Session name input listener
document.addEventListener('DOMContentLoaded', () => {
    const sessionNameInput = document.getElementById('session-name');
    if (sessionNameInput) {
        sessionNameInput.addEventListener('input', () => {
            window.biofoulingApp?.updateUploadButton();
        });
    }
});