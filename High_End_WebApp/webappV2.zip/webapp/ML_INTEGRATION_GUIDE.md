# ML Integration Guide for Marine Biofouling Detection System

## 🧠 Overview

This guide shows you how to integrate your trained Machine Learning model into the biofouling detection webapp. The system now supports multiple ML frameworks and provides a complete pipeline from image upload to analysis results.

## 🏗️ Architecture

### Backend Integration Points

1. **ML Service (`src/ml-service.ts`)**
   - Handles model loading and inference
   - Supports TensorFlow.js, ONNX, and PyTorch models
   - Provides preprocessing and postprocessing pipelines

2. **API Endpoints**
   - `/api/ml/models` - List available models
   - `/api/ml/status/:modelName` - Get model status and info
   - `/api/ml/config/:modelName` - Update model configuration
   - `/api/sessions/:id/analyze?model=modelName` - Run analysis with specific model

3. **Enhanced Analysis Pipeline**
   - Replaces mock data with actual ML inference
   - Stores ML-specific metadata (confidence scores, processing times)
   - Supports different model architectures and input formats

### Frontend Enhancements

1. **ML Configuration Panel**
   - Model selection dropdown
   - Confidence threshold slider
   - Real-time model status indicators

2. **Enhanced Loading Experience**
   - ML-specific progress indicators
   - Model information display
   - Processing time estimation

3. **Results Enhancement**
   - Confidence score visualization
   - Model metadata display
   - Processing performance metrics

## 🚀 How to Add Your ML Model

### Step 1: Prepare Your Model

1. **Export your trained model** to one of the supported formats:
   - **TensorFlow.js**: `.json` model file + weight shards
   - **ONNX**: `.onnx` model file
   - **PyTorch**: Set up a REST API service

2. **Model Requirements**:
   - Input: RGB images (any resolution - will be preprocessed)
   - Output: Bounding boxes + class probabilities + confidence scores
   - Classes: Marine biofouling species (Barnacles, Algae, Mussels, etc.)

### Step 2: Add Model Configuration

In `src/ml-service.ts`, add your model to `DEFAULT_ML_CONFIGS`:

```typescript
'your-model-name': {
  modelPath: '/models/your-model.onnx',
  modelType: 'onnx',
  inputSize: { width: 640, height: 640 },
  confidenceThreshold: 0.5,
  classes: [
    'Barnacles',
    'Algae',
    'Mussels',
    'Hydroids',
    // ... your species classes
  ]
}
```

### Step 3: Implement Model Loading

Update the `loadModel()` method in `MLInferenceService`:

```typescript
case 'onnx':
  // Example for ONNX Runtime Web
  const session = await ort.InferenceSession.create(this.config.modelPath);
  this.models.set('main', session);
  break;
```

### Step 4: Implement Preprocessing

Update `preprocessImage()` method:

```typescript
private async preprocessImage(imageBuffer: ArrayBuffer): Promise<Float32Array> {
  // 1. Decode image from buffer
  const img = await this.decodeImage(imageBuffer);
  
  // 2. Resize to model input size
  const resized = await this.resizeImage(img, this.config.inputSize);
  
  // 3. Normalize pixel values (0-1 or -1 to 1 depending on your model)
  const normalized = this.normalizePixels(resized);
  
  // 4. Convert to Float32Array in the format your model expects
  return this.imageToTensor(normalized);
}
```

### Step 5: Implement Inference

Update `runInference()` method:

```typescript
private async runInference(preprocessedImage: Float32Array): Promise<DetectionResult[]> {
  const model = this.models.get('main');
  
  // Run model inference
  const predictions = await model.run(preprocessedImage);
  
  // Post-process predictions
  return this.postProcessPredictions(predictions);
}
```

## 📁 File Structure

```
webapp/
├── src/
│   ├── index.tsx              # Main backend with ML API routes
│   ├── ml-service.ts          # ML inference service
│   └── renderer.tsx           # JSX renderer (unchanged)
├── public/
│   └── static/
│       ├── app.js             # Base application
│       ├── ml-enhanced-app.js # ML-enhanced frontend
│       └── styles.css         # Styling
└── models/                    # Your ML models (create this folder)
    ├── biofouling-detector-v1.onnx
    └── marine-vision-v2.json
```

## 🔧 Configuration Options

### Model Types Supported

1. **TensorFlow.js**
   - Best for web deployment
   - Runs directly in browser/worker
   - Good performance with WebGL acceleration

2. **ONNX Runtime Web**
   - Cross-platform model format
   - Good performance with WebAssembly
   - Supports many model architectures

3. **PyTorch (via API)**
   - For complex models or GPU inference
   - Requires separate Python service
   - Best performance for large models

### Frontend Configuration

The ML configuration panel allows users to:
- Select between different models
- Adjust confidence thresholds (0.1 - 0.9)
- View model status and performance metrics
- See real-time processing information

## 🎯 Demo Features

### Current Demo Implementation

The current implementation includes:
- **Simulated ML Pipeline**: Shows realistic processing times and results
- **Multiple Model Support**: Switchable between different model configurations
- **Progressive Loading**: ML-specific loading sequence with progress indicators
- **Enhanced Results Display**: Confidence scores, processing times, model metadata

### Test the Integration

1. **Start the development server**:
   ```bash
   npm run dev
   ```

2. **Open the webapp** and navigate to the Upload tab

3. **Configure ML settings**:
   - Select a model from the dropdown
   - Adjust confidence threshold
   - View model status

4. **Upload test images** and click "Start AI Analysis"

5. **View enhanced results** with ML-specific information

## 🔮 Next Steps

### Replace Demo with Real Models

1. **Add your trained model files** to `/public/models/`
2. **Install ML framework dependencies**:
   ```bash
   # For ONNX Runtime Web
   npm install onnxruntime-web
   
   # For TensorFlow.js
   npm install @tensorflow/tfjs
   ```
3. **Update the model loading code** in `ml-service.ts`
4. **Test with your specific model architecture**

### Advanced Features

Consider implementing:
- **Model versioning** and A/B testing
- **Batch processing** for multiple images
- **Model performance monitoring**
- **Confidence calibration**
- **Species-specific thresholds**

## 📸 Demo Images

The system includes demo images in `/public/demo/`:
- `hull1_original.jpg` - Original hull image
- `hull1_processed.jpg` - Preprocessed version
- `hull1_segmented.jpg` - Segmentation overlay

For testing with your own images, upload marine hull photos with visible biofouling.

## 🚨 Important Notes

1. **Model Security**: Ensure your models don't contain sensitive information
2. **Performance**: Large models may impact loading times
3. **Browser Compatibility**: Test ML frameworks across different browsers
4. **Error Handling**: The system gracefully handles model loading failures
5. **Scalability**: Consider model size and inference time for production use

## 📞 Integration Support

The ML integration is designed to be:
- **Modular**: Easy to swap models and frameworks
- **Extensible**: Add new model types with minimal changes  
- **Robust**: Handles errors gracefully with fallbacks
- **User-Friendly**: Clear UI feedback and configuration options

Your trained biofouling detection model will slot directly into this architecture, providing a complete end-to-end solution for marine hull analysis!