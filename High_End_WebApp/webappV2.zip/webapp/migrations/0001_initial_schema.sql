-- Marine Biofouling Detection Database Schema

-- Detection sessions for tracking analysis batches
CREATE TABLE IF NOT EXISTS detection_sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_name TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    status TEXT DEFAULT 'pending' -- pending, processing, completed, failed
);

-- Uploaded images
CREATE TABLE IF NOT EXISTS images (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL,
    filename TEXT NOT NULL,
    original_url TEXT NOT NULL,
    preprocessed_url TEXT,
    segmented_url TEXT,
    file_size INTEGER,
    width INTEGER,
    height INTEGER,
    uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (session_id) REFERENCES detection_sessions(id)
);

-- Species detected in images
CREATE TABLE IF NOT EXISTS species_detections (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    image_id INTEGER NOT NULL,
    species_name TEXT NOT NULL,
    scientific_name TEXT,
    confidence_score REAL NOT NULL,
    coverage_percentage REAL NOT NULL,
    bbox_x INTEGER,
    bbox_y INTEGER,
    bbox_width INTEGER,
    bbox_height INTEGER,
    detected_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (image_id) REFERENCES images(id)
);

-- Species information database
CREATE TABLE IF NOT EXISTS species_info (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    species_name TEXT UNIQUE NOT NULL,
    scientific_name TEXT,
    description TEXT,
    impact_level TEXT, -- low, medium, high, critical
    drag_coefficient REAL,
    invasiveness_score INTEGER, -- 1-10 scale
    cleaning_difficulty TEXT, -- easy, moderate, difficult, extreme
    recommended_actions TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Detection analytics for tracking over time
CREATE TABLE IF NOT EXISTS analytics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL,
    total_coverage_percentage REAL NOT NULL,
    dominant_species TEXT,
    species_count INTEGER,
    fuel_cost_impact REAL, -- estimated additional fuel cost
    maintenance_cost REAL, -- estimated cleaning cost
    cleaning_urgency TEXT, -- low, medium, high, critical
    calculated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (session_id) REFERENCES detection_sessions(id)
);

-- Reports generated
CREATE TABLE IF NOT EXISTS reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL,
    report_type TEXT NOT NULL, -- pdf, summary, full
    report_url TEXT,
    generated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (session_id) REFERENCES detection_sessions(id)
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_images_session_id ON images(session_id);
CREATE INDEX IF NOT EXISTS idx_species_detections_image_id ON species_detections(image_id);
CREATE INDEX IF NOT EXISTS idx_analytics_session_id ON analytics(session_id);
CREATE INDEX IF NOT EXISTS idx_reports_session_id ON reports(session_id);
CREATE INDEX IF NOT EXISTS idx_detection_sessions_created_at ON detection_sessions(created_at);