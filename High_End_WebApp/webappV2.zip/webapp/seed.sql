-- Sample species information for Marine Biofouling Detection
INSERT OR IGNORE INTO species_info (species_name, scientific_name, description, impact_level, drag_coefficient, invasiveness_score, cleaning_difficulty, recommended_actions) VALUES 
('Barnacles', 'Cirripedia', 'Hard-shelled crustaceans that attach firmly to surfaces. Create significant drag and fuel consumption increase.', 'high', 0.25, 8, 'difficult', 'Immediate mechanical cleaning required. High-pressure water jets or scraping. Schedule cleaning every 3-6 months.'),
('Green Algae', 'Chlorophyta', 'Common marine algae that forms slippery biofilms. Moderate impact on drag but easy to clean.', 'medium', 0.15, 5, 'easy', 'Regular brushing and anti-fouling coating application. Clean every 2-3 months.'),
('Brown Algae', 'Phaeophyta', 'Larger marine algae species that can form thick mats. Moderate to high drag impact.', 'high', 0.20, 6, 'moderate', 'Mechanical removal with brushes. Apply copper-based anti-fouling paint. Clean every 4-6 months.'),
('Mussels', 'Mytilus', 'Bivalve mollusks that attach with strong byssal threads. High drag coefficient and difficult removal.', 'critical', 0.30, 9, 'extreme', 'Professional cleaning required. Use specialized scraping tools. Immediate attention needed.'),
('Hydroids', 'Hydrozoa', 'Small colonial animals that form feathery growths. Low individual impact but can cover large areas.', 'medium', 0.12, 4, 'moderate', 'Soft brush cleaning. Apply biocide treatment. Monitor growth patterns.'),
('Tube Worms', 'Polychaeta', 'Segmented worms that build calcium carbonate tubes. Moderate drag impact.', 'medium', 0.18, 6, 'moderate', 'Mechanical scraping required. Use anti-fouling coatings. Clean every 6 months.'),
('Sea Squirts', 'Ascidiacea', 'Filter-feeding tunicates that form soft, gelatinous masses. High water retention increases drag.', 'high', 0.22, 7, 'difficult', 'High-pressure cleaning and scraping. Apply copper-based coatings. Professional cleaning recommended.');

-- Sample detection session
INSERT OR IGNORE INTO detection_sessions (id, session_name, status) VALUES 
(1, 'Demo Hull Inspection - Port Side', 'completed'),
(2, 'Demo Hull Inspection - Starboard Side', 'completed'),
(3, 'Demo Propeller Analysis', 'completed');

-- Sample images
INSERT OR IGNORE INTO images (id, session_id, filename, original_url, preprocessed_url, segmented_url, file_size, width, height) VALUES 
(1, 1, 'hull_section_1.jpg', '/demo/hull1_original.jpg', '/demo/hull1_processed.jpg', '/demo/hull1_segmented.jpg', 1024000, 1920, 1080),
(2, 1, 'hull_section_2.jpg', '/demo/hull2_original.jpg', '/demo/hull2_processed.jpg', '/demo/hull2_segmented.jpg', 987000, 1920, 1080),
(3, 2, 'starboard_bow.jpg', '/demo/starboard_original.jpg', '/demo/starboard_processed.jpg', '/demo/starboard_segmented.jpg', 1156000, 1920, 1080),
(4, 3, 'propeller_close.jpg', '/demo/prop_original.jpg', '/demo/prop_processed.jpg', '/demo/prop_segmented.jpg', 856000, 1920, 1080);

-- Sample species detections
INSERT OR IGNORE INTO species_detections (image_id, species_name, scientific_name, confidence_score, coverage_percentage, bbox_x, bbox_y, bbox_width, bbox_height) VALUES 
(1, 'Barnacles', 'Cirripedia', 0.94, 23.5, 100, 200, 400, 300),
(1, 'Green Algae', 'Chlorophyta', 0.87, 15.2, 600, 150, 300, 250),
(2, 'Mussels', 'Mytilus', 0.92, 31.8, 200, 300, 500, 400),
(2, 'Brown Algae', 'Phaeophyta', 0.76, 12.4, 800, 100, 250, 200),
(3, 'Barnacles', 'Cirripedia', 0.89, 18.7, 150, 250, 350, 280),
(3, 'Tube Worms', 'Polychaeta', 0.82, 8.9, 700, 400, 200, 150),
(4, 'Sea Squirts', 'Ascidiacea', 0.91, 42.3, 300, 200, 600, 450),
(4, 'Hydroids', 'Hydrozoa', 0.73, 7.6, 100, 500, 180, 120);

-- Sample analytics
INSERT OR IGNORE INTO analytics (session_id, total_coverage_percentage, dominant_species, species_count, fuel_cost_impact, maintenance_cost, cleaning_urgency) VALUES 
(1, 38.7, 'Barnacles', 2, 1250.00, 3500.00, 'high'),
(2, 44.2, 'Mussels', 3, 1580.00, 4200.00, 'critical'),
(3, 49.9, 'Sea Squirts', 2, 1820.00, 5100.00, 'critical');