#!/usr/bin/env python3
"""
Create placeholder demo images for Marine Biofouling Detection System
This script generates simple placeholder images that represent different states
"""
from PIL import Image, ImageDraw, ImageFont
import os

def create_placeholder_image(width, height, text, bg_color, text_color, filename):
    """Create a placeholder image with text"""
    image = Image.new('RGB', (width, height), bg_color)
    draw = ImageDraw.Draw(image)
    
    # Try to use a font, fallback to default if not available
    try:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 24)
    except:
        font = ImageFont.load_default()
    
    # Calculate text position to center it
    bbox = draw.textbbox((0, 0), text, font=font)
    text_width = bbox[2] - bbox[0]
    text_height = bbox[3] - bbox[1]
    
    x = (width - text_width) // 2
    y = (height - text_height) // 2
    
    draw.text((x, y), text, fill=text_color, font=font)
    
    image.save(filename)
    print(f"Created {filename}")

def main():
    # Create demo directory if it doesn't exist
    demo_dir = "/home/user/webapp/public/demo"
    os.makedirs(demo_dir, exist_ok=True)
    
    # Image dimensions
    width, height = 800, 600
    
    # Create different types of demo images
    images = [
        {
            'filename': f'{demo_dir}/hull1_original.jpg',
            'text': 'ORIGINAL\nHull Section 1\n\nBarnacles & Algae\nVisible',
            'bg_color': (45, 55, 70),
            'text_color': (200, 200, 200)
        },
        {
            'filename': f'{demo_dir}/hull1_processed.jpg',
            'text': 'PREPROCESSED\nHull Section 1\n\nEnhanced Contrast\nNoise Reduced',
            'bg_color': (35, 65, 85),
            'text_color': (220, 220, 220)
        },
        {
            'filename': f'{demo_dir}/hull1_segmented.jpg',
            'text': 'SEGMENTED\nHull Section 1\n\nFouling Regions\nHighlighted',
            'bg_color': (70, 35, 35),
            'text_color': (255, 200, 200)
        },
        {
            'filename': f'{demo_dir}/hull2_original.jpg',
            'text': 'ORIGINAL\nHull Section 2\n\nHeavy Mussel\nInfestation',
            'bg_color': (50, 45, 35),
            'text_color': (200, 200, 180)
        },
        {
            'filename': f'{demo_dir}/hull2_processed.jpg',
            'text': 'PREPROCESSED\nHull Section 2\n\nColor Corrected\nEdge Enhanced',
            'bg_color': (60, 55, 45),
            'text_color': (220, 220, 200)
        },
        {
            'filename': f'{demo_dir}/hull2_segmented.jpg',
            'text': 'SEGMENTED\nHull Section 2\n\nMussel Colonies\nMapped',
            'bg_color': (80, 35, 70),
            'text_color': (255, 200, 240)
        },
        {
            'filename': f'{demo_dir}/starboard_original.jpg',
            'text': 'ORIGINAL\nStarboard Bow\n\nMixed Fouling\nTypes Present',
            'bg_color': (40, 50, 60),
            'text_color': (190, 210, 220)
        },
        {
            'filename': f'{demo_dir}/starboard_processed.jpg',
            'text': 'PREPROCESSED\nStarboard Bow\n\nOptimal Lighting\nClarity Enhanced',
            'bg_color': (50, 60, 70),
            'text_color': (210, 220, 230)
        },
        {
            'filename': f'{demo_dir}/starboard_segmented.jpg',
            'text': 'SEGMENTED\nStarboard Bow\n\nSpecies Boundaries\nDefined',
            'bg_color': (35, 70, 45),
            'text_color': (200, 255, 220)
        },
        {
            'filename': f'{demo_dir}/prop_original.jpg',
            'text': 'ORIGINAL\nPropeller Close-up\n\nSea Squirts &\nHydroids Detected',
            'bg_color': (55, 40, 50),
            'text_color': (220, 190, 210)
        },
        {
            'filename': f'{demo_dir}/prop_processed.jpg',
            'text': 'PREPROCESSED\nPropeller Close-up\n\nSurface Details\nClarified',
            'bg_color': (65, 50, 60),
            'text_color': (230, 210, 220)
        },
        {
            'filename': f'{demo_dir}/prop_segmented.jpg',
            'text': 'SEGMENTED\nPropeller Close-up\n\nBiofilm Areas\nIsolated',
            'bg_color': (70, 70, 35),
            'text_color': (255, 255, 200)
        }
    ]
    
    # Generate all demo images
    for img_config in images:
        create_placeholder_image(
            width, height,
            img_config['text'],
            img_config['bg_color'],
            img_config['text_color'],
            img_config['filename']
        )
    
    print(f"\nSuccessfully created {len(images)} demo images in {demo_dir}/")
    print("Demo images are now available for the biofouling detection system!")

if __name__ == "__main__":
    main()