import { Hono } from 'hono'
import { cors } from 'hono/cors'
import { serveStatic } from 'hono/cloudflare-workers'
import { getMLService, DEFAULT_ML_CONFIGS } from './ml-service'

type Bindings = {
  DB: D1Database;
  R2: R2Bucket;
}

const app = new Hono<{ Bindings: Bindings }>()

// Enable CORS for all routes
app.use('*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization']
}))

// Serve static files
app.use('/static/*', serveStatic({ root: './public' }))
app.use('/demo/*', serveStatic({ root: './public' }))

// ML Model API Routes
app.get('/api/ml/models', (c) => {
  const models = Object.keys(DEFAULT_ML_CONFIGS).map(name => ({
    name,
    ...DEFAULT_ML_CONFIGS[name]
  }))
  return c.json({ models })
})

app.get('/api/ml/status/:modelName?', (c) => {
  const modelName = c.req.param('modelName') || 'biofouling-detector-v1'
  try {
    const mlService = getMLService(modelName)
    const status = mlService.getModelInfo()
    return c.json({ status, modelName })
  } catch (error) {
    return c.json({ error: 'Model not found' }, 404)
  }
})

app.post('/api/ml/config/:modelName', async (c) => {
  const modelName = c.req.param('modelName') || 'biofouling-detector-v1'
  try {
    const body = await c.req.json()
    const mlService = getMLService(modelName)
    mlService.updateConfig(body)
    return c.json({ success: true, config: mlService.getModelInfo() })
  } catch (error) {
    return c.json({ error: 'Failed to update config' }, 400)
  }
})

// API Routes
app.get('/api/sessions', async (c) => {
  const { env } = c
  
  try {
    const result = await env.DB.prepare(`
      SELECT s.*, 
             COUNT(i.id) as image_count,
             GROUP_CONCAT(i.filename) as image_filenames
      FROM detection_sessions s
      LEFT JOIN images i ON s.id = i.session_id
      GROUP BY s.id
      ORDER BY s.created_at DESC
      LIMIT 10
    `).all()
    
    return c.json(result.results)
  } catch (error) {
    return c.json({ error: 'Database error' }, 500)
  }
})

app.get('/api/sessions/:id', async (c) => {
  const { env } = c
  const sessionId = c.req.param('id')
  
  try {
    // Get session details
    const sessionResult = await env.DB.prepare(`
      SELECT * FROM detection_sessions WHERE id = ?
    `).bind(sessionId).first()
    
    if (!sessionResult) {
      return c.notFound()
    }
    
    // Get session images
    const imagesResult = await env.DB.prepare(`
      SELECT * FROM images WHERE session_id = ? ORDER BY uploaded_at ASC
    `).bind(sessionId).all()
    
    // Get detection results if available (using correct table name)
    const resultsResult = await env.DB.prepare(`
      SELECT sd.*, i.filename FROM species_detections sd 
      JOIN images i ON sd.image_id = i.id 
      WHERE i.session_id = ? ORDER BY sd.detected_at ASC
    `).bind(sessionId).all()
    
    // Get analytics if available
    const analyticsResult = await env.DB.prepare(`
      SELECT * FROM analytics WHERE session_id = ?
    `).bind(sessionId).first()
    
    return c.json({
      session: sessionResult,
      images: imagesResult.results || [],
      detections: resultsResult.results || [],
      analytics: analyticsResult
    })
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error'
    return c.json({ error: 'Failed to load session details', details: errorMessage }, 500)
  }
})

app.post('/api/sessions', async (c) => {
  const { env } = c
  
  try {
    const body = await c.req.json()
    const sessionName = body.sessionName || `Session ${new Date().toISOString()}`
    
    const result = await env.DB.prepare(`
      INSERT INTO detection_sessions (session_name, status, created_at, updated_at)
      VALUES (?, 'pending', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
    `).bind(sessionName).run()
    
    return c.json({ 
      sessionId: result.meta.last_row_id,
      sessionName: sessionName
    })
  } catch (error) {
    return c.json({ error: 'Database error' }, 500)
  }
})

app.post('/api/sessions/:id/upload', async (c) => {
  const { env } = c
  const sessionId = c.req.param('id')
  
  try {
    const formData = await c.req.formData()
    const files = formData.getAll('images')
    
    const uploadedImages: any[] = []
    
    for (const file of files) {
      if (file && typeof file === 'object' && 'stream' in file) {
        const fileObj = file as any
        const key = `sessions/${sessionId}/${Date.now()}-${fileObj.name}`
        
        try {
          // Try to store in R2, but handle errors gracefully
          await env.R2.put(key, fileObj.stream())
          
          // Store metadata in database
          const result = await env.DB.prepare(`
            INSERT INTO images (session_id, filename, original_url, file_size, width, height)
            VALUES (?, ?, ?, ?, ?, ?)
          `).bind(
            sessionId,
            fileObj.name,
            `/api/images/${key}`,
            fileObj.size,
            1920,
            1080
          ).run()
        
          uploadedImages.push({
            id: result.meta.last_row_id,
            filename: fileObj.name,
            original_url: `/api/images/${key}`,
            file_size: fileObj.size
          })
        } catch (uploadError) {
          // For local development, still add to database but with placeholder URL
          const result = await env.DB.prepare(`
            INSERT INTO images (session_id, filename, original_url, file_size, width, height)
            VALUES (?, ?, ?, ?, ?, ?)
          `).bind(
            sessionId,
            fileObj.name,
            `/demo/hull1_original.jpg`, // Use demo image as placeholder
            fileObj.size,
            1920,
            1080
          ).run()
        
          uploadedImages.push({
            id: result.meta.last_row_id,
            filename: fileObj.name,
            original_url: `/demo/hull1_original.jpg`,
            file_size: fileObj.size
          })
        }
      }
    }
    
    // Update session status
    await env.DB.prepare(`
      UPDATE detection_sessions SET status = 'processing', updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).bind(sessionId).run()
    
    return c.json({ 
      message: 'Images uploaded successfully',
      images: uploadedImages
    })
  } catch (error) {
    return c.json({ error: 'Failed to upload images' }, 500)
  }
})

// Favicon route to prevent 500 errors
app.get('/favicon.ico', (c) => {
  return c.redirect('/demo/hull1_original.jpg')
})

// Image serving route with fallback to demo images
app.get('/api/images/*', async (c) => {
  const { env } = c
  const path = c.req.path.replace('/api/images/', '')
  
  try {
    const object = await env.R2.get(path)
    if (object) {
      return new Response(object.body, {
        headers: {
          'Content-Type': object.httpMetadata?.contentType || 'image/jpeg',
          'Cache-Control': 'public, max-age=31536000',
          'Access-Control-Allow-Origin': '*'
        }
      })
    }
  } catch (error) {
    // Fallback to demo images for local development
  }
  
  // Return demo image as fallback
  return c.redirect('/demo/hull1_original.jpg')
})

app.post('/api/sessions/:id/analyze', async (c) => {
  const { env } = c
  const sessionId = c.req.param('id')
  
  try {
    // Get model name from query params or use default
    const modelName = c.req.query('model') || 'biofouling-detector-v1'
    const mlService = getMLService(modelName)
    
    // Get all images for this session
    const imagesResult = await env.DB.prepare(`
      SELECT * FROM images WHERE session_id = ?
    `).bind(sessionId).all()
    
    const images = imagesResult.results || []
    
    if (images.length === 0) {
      return c.json({ error: 'No images found for this session' }, 400)
    }
    
    let totalCoverage = 0
    let allDetections: any[] = []
    let processingTimes: number[] = []
    
    // Analyze each image with ML model
    for (const image of images) {
      try {
        // For demo purposes, create a mock image buffer
        // In real implementation, you would fetch the actual image:
        // const imageResponse = await fetch(image.original_url)
        // const imageBuffer = await imageResponse.arrayBuffer()
        
        const mockImageBuffer = new ArrayBuffer(1024 * 1024) // 1MB mock buffer
        
        // Run ML analysis
        const analysisResult = await mlService.analyzeImage(mockImageBuffer, image.filename)
        
        processingTimes.push(analysisResult.processing_time_ms)
        totalCoverage += analysisResult.total_coverage
        
        // Store ML detections in database
        for (const detection of analysisResult.detections) {
          const result = await env.DB.prepare(`
            INSERT INTO species_detections (
              image_id, species_name, scientific_name, confidence_score, 
              coverage_percentage, bbox_x, bbox_y, bbox_width, bbox_height,
              detected_at, model_version
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, ?)
          `).bind(
            image.id,
            detection.species,
            detection.scientific_name || '',
            detection.confidence,
            detection.coverage_percentage,
            detection.bbox.x,
            detection.bbox.y,
            detection.bbox.width,
            detection.bbox.height,
            analysisResult.model_version
          ).run()
          
          allDetections.push({
            ...detection,
            id: result.meta.last_row_id,
            image_id: image.id
          })
        }
        
        // Update image with processed URLs (using demo images for now)
        await env.DB.prepare(`
          UPDATE images SET 
            preprocessed_url = ?,
            segmented_url = ?,
            analysis_completed_at = CURRENT_TIMESTAMP,
            ml_model_used = ?
          WHERE id = ?
        `).bind(
          '/demo/hull1_processed.jpg',
          '/demo/hull1_segmented.jpg',
          modelName,
          image.id
        ).run()
        
      } catch (imageError) {
        console.error(`Failed to analyze image ${image.filename}:`, imageError)
        // Continue with other images even if one fails
      }
    }
    
    // Calculate dominant species from all detections
    const speciesCoverage: Record<string, number> = {}
    allDetections.forEach(det => {
      speciesCoverage[det.species] = (speciesCoverage[det.species] || 0) + det.coverage_percentage
    })
    
    const dominantSpecies = Object.entries(speciesCoverage)
      .sort(([,a], [,b]) => b - a)[0]?.[0] || 'None detected'
    
    const avgProcessingTime = processingTimes.length > 0 
      ? processingTimes.reduce((a, b) => a + b, 0) / processingTimes.length 
      : 0
    
    // Create analytics summary with ML results
    await env.DB.prepare(`
      INSERT INTO analytics (
        session_id, total_coverage_percentage, dominant_species, 
        species_count, fuel_cost_impact, maintenance_cost, cleaning_urgency,
        ml_model_used, avg_confidence, processing_time_ms
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      sessionId,
      Math.min(totalCoverage, 100),
      dominantSpecies,
      Object.keys(speciesCoverage).length,
      totalCoverage * 2.5, // estimated fuel cost
      totalCoverage * 15, // estimated cleaning cost
      totalCoverage > 70 ? 'critical' : totalCoverage > 40 ? 'high' : totalCoverage > 20 ? 'medium' : 'low',
      modelName,
      allDetections.length > 0 ? allDetections.reduce((sum, det) => sum + det.confidence, 0) / allDetections.length : 0,
      avgProcessingTime
    ).run()
    
    // Update session status
    await env.DB.prepare(`
      UPDATE detection_sessions SET 
        status = 'completed', 
        updated_at = CURRENT_TIMESTAMP,
        ml_model_used = ?
      WHERE id = ?
    `).bind(modelName, sessionId).run()
    
    return c.json({ 
      message: 'ML analysis completed successfully',
      results: {
        totalDetections: allDetections.length,
        totalCoverage: Math.min(totalCoverage, 100),
        dominantSpecies,
        modelUsed: modelName,
        avgProcessingTime
      }
    })
  } catch (error) {
    console.error('ML analysis failed:', error)
    
    // Update session status to failed
    try {
      await env.DB.prepare(`
        UPDATE detection_sessions SET status = 'failed', updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).bind(sessionId).run()
    } catch (dbError) {
      console.error('Failed to update session status:', dbError)
    }
    
    return c.json({ 
      error: 'ML analysis failed', 
      details: error instanceof Error ? error.message : 'Unknown error'
    }, 500)
  }
})

app.delete('/api/sessions/:id', async (c) => {
  const { env } = c
  const sessionId = c.req.param('id')
  
  try {
    // Delete in correct order due to foreign key constraints
    await env.DB.prepare(`DELETE FROM detection_results WHERE session_id = ?`).bind(sessionId).run()
    await env.DB.prepare(`DELETE FROM images WHERE session_id = ?`).bind(sessionId).run()
    await env.DB.prepare(`DELETE FROM detection_sessions WHERE id = ?`).bind(sessionId).run()
    
    return c.json({ message: 'Session deleted successfully' })
  } catch (error) {
    return c.json({ error: 'Database error' }, 500)
  }
})

// Frontend route
app.get('/', (c) => {
  return c.html(`
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Marine Biofouling Detection System</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/axios@1.6.0/dist/axios.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jspdf@2.5.1/dist/jspdf.umd.min.js"></script>
    <link href="/static/styles.css" rel="stylesheet">
</head>
<body class="min-h-screen text-white">
    <!-- Floating Shapes -->
    <div class="floating-shapes">
        <div class="shape"></div>
        <div class="shape"></div>
        <div class="shape"></div>
    </div>

    <!-- Header -->
    <header class="glass sticky top-0 z-40 p-6">
        <div class="max-w-7xl mx-auto flex items-center justify-between">
            <div class="flex items-center space-x-6">
                <div class="relative">
                    <div class="absolute inset-0 bg-gradient-to-r from-blue-400 to-purple-500 rounded-full blur-lg opacity-70"></div>
                    <i class="fas fa-ship text-white text-3xl relative z-10"></i>
                </div>
                <div>
                    <h1 class="text-3xl font-bold gradient-text">Marine Biofouling</h1>
                    <p class="text-sm text-gray-300 font-light">AI-Powered Detection System</p>
                </div>
            </div>
            <div class="flex items-center space-x-6">
                <div class="hidden md:block text-right">
                    <p class="text-xs text-gray-400 uppercase tracking-wide">Last Analysis</p>
                    <span class="text-sm font-medium" id="last-analysis">--</span>
                </div>
                <button id="new-session-btn" class="glass-button px-6 py-3 font-medium">
                    <i class="fas fa-plus mr-2"></i>New Session
                </button>
            </div>
        </div>
    </header>

    <!-- Navigation Tabs -->
    <nav class="max-w-7xl mx-auto px-6 py-4">
        <div class="glass rounded-2xl p-2">
            <div class="flex flex-wrap gap-2">
                <button class="tab-button tab-active px-6 py-3 rounded-xl transition-all font-medium" data-tab="upload">
                    <i class="fas fa-cloud-upload-alt mr-2"></i>Upload
                </button>
                <button class="tab-button tab-inactive px-6 py-3 rounded-xl transition-all font-medium" data-tab="results">
                    <i class="fas fa-microscope mr-2"></i>Results
                </button>
                <button class="tab-button tab-inactive px-6 py-3 rounded-xl transition-all font-medium" data-tab="analytics">
                    <i class="fas fa-chart-line mr-2"></i>Analytics
                </button>
                <button class="tab-button tab-inactive px-6 py-3 rounded-xl transition-all font-medium" data-tab="3d-viz">
                    <i class="fas fa-cube mr-2"></i>3D View
                </button>
                <button class="tab-button tab-inactive px-6 py-3 rounded-xl transition-all font-medium" data-tab="reports">
                    <i class="fas fa-file-alt mr-2"></i>Reports
                </button>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main class="max-w-7xl mx-auto p-6">
        <!-- Upload Tab -->
        <div id="tab-upload" class="tab-content">
            <div class="grid lg:grid-cols-2 gap-8">
                <!-- Upload Section -->
                <div class="glass-card p-8">
                    <div class="flex items-center justify-between mb-6">
                        <h2 class="text-2xl font-bold gradient-text flex items-center">
                            <i class="fas fa-cloud-upload-alt mr-3"></i>
                            Upload Images
                        </h2>
                        <span class="px-3 py-1 text-xs font-medium bg-green-500/20 text-green-300 rounded-full border border-green-500/30">
                            AI Ready
                        </span>
                    </div>
                    
                    <div class="space-y-6">
                        <div>
                            <label class="block text-sm font-semibold text-gray-300 mb-3">Session Name</label>
                            <input type="text" id="session-name" class="w-full glass px-4 py-3 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-400/50 transition-all" placeholder="e.g., Hull Inspection - Port Side">
                        </div>
                        
                        <div class="glass-card p-6 border border-blue-500/20">
                            <div class="flex items-center justify-between mb-4">
                                <h3 class="text-lg font-semibold gradient-text flex items-center">
                                    <i class="fas fa-brain mr-2"></i>ML Model Configuration
                                </h3>
                                <span class="px-3 py-1 text-xs font-medium bg-purple-500/20 text-purple-300 rounded-full border border-purple-500/30">
                                    AI Powered
                                </span>
                            </div>
                            
                            <div class="grid md:grid-cols-2 gap-4">
                                <div>
                                    <label class="block text-sm font-medium text-gray-300 mb-2">Detection Model</label>
                                    <select id="model-select" class="w-full glass px-4 py-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400/50">
                                        <option value="biofouling-detector-v1">Biofouling Detector v1 (ONNX)</option>
                                        <option value="marine-vision-v2">Marine Vision v2 (TensorFlow)</option>
                                    </select>
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-300 mb-2">Confidence Threshold</label>
                                    <div class="flex items-center space-x-3">
                                        <input type="range" id="confidence-slider" min="0.1" max="0.9" step="0.1" value="0.5" class="flex-1">
                                        <span id="confidence-value" class="text-sm font-mono text-blue-400 min-w-[3rem]">0.5</span>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mt-4 grid md:grid-cols-3 gap-3 text-sm">
                                <div class="flex items-center space-x-2 text-gray-400">
                                    <i class="fas fa-microchip text-blue-400"></i>
                                    <span>Model Status: <span id="model-status" class="text-green-400">Ready</span></span>
                                </div>
                                <div class="flex items-center space-x-2 text-gray-400">
                                    <i class="fas fa-clock text-yellow-400"></i>
                                    <span>Avg Time: <span id="processing-time">~2.3s</span></span>
                                </div>
                                <div class="flex items-center space-x-2 text-gray-400">
                                    <i class="fas fa-eye text-purple-400"></i>
                                    <span>Classes: <span id="model-classes">7 species</span></span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="glass border-2 border-dashed border-white/20 rounded-2xl p-12 text-center hover:border-blue-400/50 transition-all duration-300 cursor-pointer" id="drop-zone">
                            <div class="relative mb-6">
                                <div class="absolute inset-0 bg-gradient-to-r from-blue-400 to-purple-500 rounded-full blur-2xl opacity-30"></div>
                                <i class="fas fa-images text-6xl text-white relative z-10"></i>
                            </div>
                            <h3 class="text-xl font-semibold mb-2">Drop images here</h3>
                            <p class="text-gray-400 mb-4">or click to browse your files</p>
                            <div class="flex items-center justify-center space-x-4 text-sm text-gray-500">
                                <span class="flex items-center"><i class="fas fa-check mr-1 text-green-400"></i>JPG</span>
                                <span class="flex items-center"><i class="fas fa-check mr-1 text-green-400"></i>PNG</span>
                                <span class="flex items-center"><i class="fas fa-check mr-1 text-green-400"></i>Multiple files</span>
                            </div>
                            <input type="file" id="file-input" multiple accept="image/*" class="hidden">
                            <button type="button" class="mt-6 glass-button px-8 py-3 font-semibold" onclick="document.getElementById('file-input').click()">
                                <i class="fas fa-folder-open mr-2"></i>Browse Files
                            </button>
                        </div>
                        
                        <div id="file-list" class="space-y-3"></div>
                        
                        <button id="upload-btn" class="w-full glass-button px-6 py-4 font-semibold text-lg disabled:opacity-50 disabled:cursor-not-allowed" disabled>
                            <i class="fas fa-rocket mr-3"></i>Start AI Analysis
                        </button>
                    </div>
                </div>

                <!-- Recent Sessions -->
                <div class="glass-card p-8">
                    <div class="flex items-center justify-between mb-6">
                        <h2 class="text-2xl font-bold gradient-text flex items-center">
                            <i class="fas fa-history mr-3"></i>
                            Recent Sessions
                        </h2>
                        <button class="glass-button px-4 py-2 text-sm">
                            <i class="fas fa-sync-alt mr-2"></i>Refresh
                        </button>
                    </div>
                    <div id="recent-sessions" class="space-y-4">
                        <div class="text-center text-gray-400 py-12">
                            <div class="pulse-animation mb-4">
                                <i class="fas fa-spinner fa-spin text-3xl"></i>
                            </div>
                            <p class="text-lg font-medium">Loading sessions...</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Results Tab -->
        <div id="tab-results" class="tab-content hidden">
            <div id="results-content">
                <div class="glass-card p-12 text-center">
                    <div class="relative mb-8">
                        <div class="absolute inset-0 bg-gradient-to-r from-purple-400 to-blue-500 rounded-full blur-2xl opacity-30"></div>
                        <i class="fas fa-microscope text-6xl text-white relative z-10"></i>
                    </div>
                    <h3 class="text-2xl font-bold gradient-text mb-4">Ready for Analysis</h3>
                    <p class="text-gray-400 text-lg">Select a session to view detailed results and insights</p>
                </div>
            </div>
        </div>

        <!-- Analytics Tab -->
        <div id="tab-analytics" class="tab-content hidden">
            <div class="grid lg:grid-cols-2 gap-8">
                <div class="glass-card p-6">
                    <h3 class="text-xl font-bold gradient-text mb-6 flex items-center">
                        <i class="fas fa-chart-pie mr-3"></i>Species Distribution
                    </h3>
                    <canvas id="species-chart"></canvas>
                </div>
                <div class="glass-card p-6">
                    <h3 class="text-xl font-bold gradient-text mb-6 flex items-center">
                        <i class="fas fa-dollar-sign mr-3"></i>Cost Analysis
                    </h3>
                    <canvas id="cost-chart"></canvas>
                </div>
                <div class="glass-card p-6 lg:col-span-2">
                    <h3 class="text-xl font-bold gradient-text mb-6 flex items-center">
                        <i class="fas fa-chart-line mr-3"></i>Fouling Density Trends
                    </h3>
                    <canvas id="density-chart"></canvas>
                </div>
            </div>
        </div>

        <!-- 3D Visualization Tab -->
        <div id="tab-3d-viz" class="tab-content hidden">
            <div class="glass-card p-8">
                <div class="flex items-center justify-between mb-6">
                    <h3 class="text-2xl font-bold gradient-text flex items-center">
                        <i class="fas fa-cube mr-3"></i>
                        3D Hull Visualization
                    </h3>
                    <div class="flex items-center space-x-2">
                        <span class="px-3 py-1 text-xs font-medium bg-purple-500/20 text-purple-300 rounded-full border border-purple-500/30">
                            Interactive
                        </span>
                        <span class="px-3 py-1 text-xs font-medium bg-blue-500/20 text-blue-300 rounded-full border border-blue-500/30">
                            Real-time
                        </span>
                    </div>
                </div>
                <div id="three-container" class="w-full h-96 glass rounded-2xl overflow-hidden mb-6"></div>
                <div class="flex justify-center space-x-4">
                    <button class="glass-button px-6 py-3 font-medium">
                        <i class="fas fa-sync-alt mr-2"></i>Auto Rotate
                    </button>
                    <button class="glass-button px-6 py-3 font-medium">
                        <i class="fas fa-search-plus mr-2"></i>Zoom In
                    </button>
                    <button class="glass-button px-6 py-3 font-medium">
                        <i class="fas fa-search-minus mr-2"></i>Zoom Out
                    </button>
                    <button class="glass-button px-6 py-3 font-medium">
                        <i class="fas fa-home mr-2"></i>Reset View
                    </button>
                </div>
            </div>
        </div>

        <!-- Reports Tab -->
        <div id="tab-reports" class="tab-content hidden">
            <div class="glass-card p-8">
                <div class="flex items-center justify-between mb-8">
                    <h3 class="text-2xl font-bold gradient-text flex items-center">
                        <i class="fas fa-file-alt mr-3"></i>
                        Generate Reports
                    </h3>
                    <span class="px-3 py-1 text-xs font-medium bg-green-500/20 text-green-300 rounded-full border border-green-500/30">
                        Export Ready
                    </span>
                </div>
                <div class="grid md:grid-cols-3 gap-6">
                    <button class="glass-card p-8 text-center hover:scale-105 transition-all duration-300 group">
                        <div class="relative mb-4">
                            <div class="absolute inset-0 bg-gradient-to-r from-red-400 to-pink-500 rounded-full blur-xl opacity-50 group-hover:opacity-70 transition-opacity"></div>
                            <i class="fas fa-file-pdf text-4xl text-white relative z-10"></i>
                        </div>
                        <h4 class="font-bold text-lg mb-2">Complete PDF</h4>
                        <p class="text-sm text-gray-400">Comprehensive analysis with detailed images and findings</p>
                    </button>
                    <button class="glass-card p-8 text-center hover:scale-105 transition-all duration-300 group">
                        <div class="relative mb-4">
                            <div class="absolute inset-0 bg-gradient-to-r from-orange-400 to-yellow-500 rounded-full blur-xl opacity-50 group-hover:opacity-70 transition-opacity"></div>
                            <i class="fas fa-chart-bar text-4xl text-white relative z-10"></i>
                        </div>
                        <h4 class="font-bold text-lg mb-2">Analytics Only</h4>
                        <p class="text-sm text-gray-400">Statistical summary with charts and key metrics</p>
                    </button>
                    <button class="glass-card p-8 text-center hover:scale-105 transition-all duration-300 group">
                        <div class="relative mb-4">
                            <div class="absolute inset-0 bg-gradient-to-r from-green-400 to-blue-500 rounded-full blur-xl opacity-50 group-hover:opacity-70 transition-opacity"></div>
                            <i class="fas fa-clipboard-list text-4xl text-white relative z-10"></i>
                        </div>
                        <h4 class="font-bold text-lg mb-2">Action Plan</h4>
                        <p class="text-sm text-gray-400">Targeted maintenance recommendations and priorities</p>
                    </button>
                </div>
            </div>
        </div>
    </main>

    <!-- Loading Modal -->
    <div id="loading-modal" class="fixed inset-0 bg-black/60 backdrop-blur-md hidden items-center justify-center z-50">
        <div class="glass-card p-12 text-center max-w-md mx-4">
            <div class="relative mb-8">
                <div class="absolute inset-0 bg-gradient-to-r from-blue-400 to-purple-500 rounded-full blur-2xl opacity-50 animate-pulse"></div>
                <div class="animate-spin rounded-full h-20 w-20 border-4 border-transparent border-t-blue-400 border-r-purple-500 mx-auto relative z-10"></div>
            </div>
            <h3 class="text-2xl font-bold gradient-text mb-3">AI Processing</h3>
            <p class="text-gray-400 text-lg mb-4">Analyzing biofouling patterns...</p>
            <div class="progress-bar mb-2">
                <div class="progress-fill" style="width: 0%" id="progress-fill"></div>
            </div>
            <p class="text-sm text-gray-500" id="progress-text">Initializing...</p>
        </div>
    </div>

    <script src="/static/app.js"></script>
    <script src="/static/ml-enhanced-app.js"></script>
    
    <!-- ML Enhancement Note: The ML-enhanced app automatically replaces the basic app -->
    <!-- No additional initialization needed as it's handled in ml-enhanced-app.js -->
</body>
</html>
  `)
})

export default app