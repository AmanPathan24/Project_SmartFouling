# Marine Fouling Image Preprocessing Pipeline

A comprehensive, end-to-end image preprocessing pipeline specifically designed for marine fouling detection and classification. This system handles the unique challenges of underwater imaging including poor lighting conditions, low contrast, noise, and color distortion.

## 🌊 Problem Statement

Marine fouling (biofouling) refers to the undesirable accumulation of microorganisms, plants, algae, and animals on submerged surfaces. This phenomenon significantly impacts naval operations by:

- Increasing drag and reducing ship speed
- Elevating fuel consumption
- Potential introduction of invasive species
- Compromising hull integrity over time

This preprocessing pipeline prepares underwater images for machine learning models to classify fouling species and assess fouling density.

## 🚀 Features

### Core Preprocessing Capabilities
- **CLAHE (Contrast Limited Adaptive Histogram Equalization)**: Enhances local contrast in low-light underwater conditions
- **Multi-Scale Retinex**: Corrects non-uniform illumination and color distortion
- **Noise Reduction**: Bilateral filtering combined with Gaussian blur for edge-preserving denoising
- **Color Correction**: Specialized underwater color balance correction
- **Gamma Correction**: Brightness adjustment optimized for marine environments
- **Image Sharpening**: Unsharp masking for enhanced detail visibility

### Advanced Preprocessing Techniques
- **Homomorphic Filtering**: Separates illumination and reflectance components for better lighting normalization
- **Advanced White Balance**: Multiple algorithms (Gray World, Max White, Perfect Reflector) for superior color correction
- **Dark Channel Prior**: Removes haze and scattering effects common in underwater environments
- **Gabor Filters**: Multi-orientation texture enhancement specifically tuned for fouling patterns
- **Multi-Scale Enhancement**: Pyramid-based detail enhancement at multiple scales for various fouling sizes
- **Morphological Operations**: Shape-based boundary enhancement for better organism definition
- **Histogram Specification**: Normalizes images to target distributions for consistent appearance

### Advanced Data Augmentation
- **Underwater-Specific Effects**: Simulated marine snow, suspended particles, and water distortion
- **Color Cast Simulation**: Realistic blue/green underwater tinting
- **Light Attenuation**: Depth-based lighting effects
- **Geometric Transformations**: Rotation, scaling, shifting with underwater-appropriate parameters
- **Environmental Simulation**: Fog, motion blur, and optical distortion

### Batch Processing
- **Multiprocessing Support**: Efficient parallel processing of image batches
- **Progress Tracking**: Real-time progress monitoring with detailed statistics
- **Error Handling**: Robust error management with detailed logging
- **Flexible Output**: Multiple output formats and organizational structures

## 📦 Installation

### Requirements
- Python 3.8+
- OpenCV 4.8+
- NumPy 1.24+
- scikit-image 0.21+

### Setup
```bash
# Clone or download the project
cd marine_fouling_preprocessing

# Install dependencies
pip install -r requirements.txt
```

## 🎯 Recommended Preprocessing Order

Based on underwater imaging challenges, the pipeline follows this optimized order:

1. **Noise Reduction** - Remove sensor noise first to improve subsequent operations
2. **Color Correction** - Correct underwater color cast early
3. **Lighting Enhancement** - Apply CLAHE and Retinex for illumination correction
4. **Contrast Enhancement** - Improve overall contrast after lighting correction
5. **Sharpening** - Enhance edge definition for better feature detection
6. **Resize** - Adjust to target dimensions (if needed)
7. **Normalization** - Final normalization for ML model input

This order can be customized through configuration files or programmatically.

## 🛠️ Usage

### Basic Single Image Processing

```python
from src.image_preprocessor import ImagePreprocessor
from src.config import create_marine_optimized_config

# Create marine-optimized configuration
config = create_marine_optimized_config()

# Initialize preprocessor
preprocessor = ImagePreprocessor(config.preprocessing.__dict__)

# Load and process image
image = preprocessor.load_image('underwater_image.jpg')
processed_image = preprocessor.process_single_image(image)
```

### Command Line Usage

#### Single Image Processing
```bash
python examples/basic_example.py input_image.jpg output_image.jpg
```

#### Batch Processing
```bash
# Basic batch processing
python examples/batch_example.py input_directory/ output_directory/

# With data augmentation
python examples/batch_example.py input_directory/ output_directory/ --augment --num-aug 3

# Custom worker configuration
python examples/batch_example.py input_directory/ output_directory/ --workers 4
```

### Advanced Configuration

#### Custom Pipeline Configuration
```python
from src.config import PreprocessingConfig, PipelineConfig

# Create custom preprocessing configuration
custom_preprocessing = PreprocessingConfig(
    clahe_clip_limit=4.0,
    retinex_sigma_list=[20, 100, 300],
    gamma_correction=1.3,
    preprocessing_order=[
        'noise_reduction',
        'color_correction', 
        'lighting_enhancement',
        'contrast_enhancement',
        'sharpening',
        'normalization'
    ]
)

# Use in pipeline
preprocessor = ImagePreprocessor(custom_preprocessing.__dict__)
```

#### Batch Processing with Custom Configuration
```python
from src.batch_processor import BatchProcessor
from src.config import create_marine_optimized_config

config = create_marine_optimized_config()

# Customize batch settings
config.batch_processing.num_workers = 6
config.batch_processing.apply_augmentation = True
config.batch_processing.num_augmentations = 2

# Process directory
processor = BatchProcessor({
    'preprocessing_config': config.preprocessing.__dict__,
    'augmentation_config': config.augmentation.__dict__,
    **config.batch_processing.__dict__
})

summary = processor.process_directory('input/', 'output/')
```

## 🔧 Configuration Options

### Preprocessing Parameters

| Parameter | Description | Default | Marine Optimized |
|-----------|-------------|---------|------------------|
| `clahe_clip_limit` | CLAHE clipping limit | 3.0 | 4.0 |
| `clahe_tile_grid_size` | CLAHE tile grid size | (8, 8) | (6, 6) |
| `retinex_sigma_list` | Retinex scale parameters | [15, 80, 250] | [20, 100, 300] |
| `gamma_correction` | Gamma correction value | 1.2 | 1.3 |
| `sharpening_strength` | Sharpening intensity | 0.5 | 0.7 |

### Augmentation Parameters

| Parameter | Description | Default | Marine Optimized |
|-----------|-------------|---------|------------------|
| `particles_density` | Marine particle simulation | 0.1 | 0.15 |
| `color_cast_strength` | Underwater color tint | 0.3 | 0.4 |
| `water_distortion_alpha` | Water distortion strength | 50 | 60 |
| `underwater_prob` | Underwater effects probability | 0.5 | 0.7 |

## 📊 Pipeline Performance

### Processing Speed (Typical)
- **Single Image (1920x1080)**: ~2-4 seconds
- **Batch Processing (8 workers)**: ~0.5-1 second per image
- **With Augmentation**: +50% processing time

### Memory Usage
- **Base Pipeline**: ~200-500MB RAM
- **Batch Processing**: Scales with number of workers
- **Large Images (4K+)**: ~1-2GB RAM recommended

## 🔬 Technical Details

### CLAHE Implementation
- Applied in LAB color space for better results
- Processes L channel while preserving A and B channels
- Optimized tile size for underwater image characteristics

### Multi-Scale Retinex
- Uses logarithmic processing for illumination correction
- Three-scale approach with marine-optimized sigma values
- Handles extreme underwater lighting conditions

### Data Augmentation Techniques
1. **Marine Particle Simulation**: Adds realistic suspended matter
2. **Underwater Color Cast**: Simulates depth-based color shifts
3. **Light Attenuation**: Gradient-based depth effects
4. **Water Distortion**: Elastic transformations mimicking water movement

## 📁 Output Structure

```
output_directory/
├── original/          # Original images (if enabled)
├── preprocessed/      # Preprocessed images
├── augmented/         # Augmented images (if enabled)
├── processing_report.json    # Detailed processing statistics
└── error_log.json     # Error details (if any failures)
```

## 🐛 Troubleshooting

### Common Issues

1. **Memory Errors with Large Images**
   - Reduce batch size or number of workers
   - Consider resizing images before processing

2. **Slow Processing**
   - Enable multiprocessing for batch jobs
   - Adjust worker count based on CPU cores

3. **Color Issues**
   - Ensure images are in RGB format
   - Check for proper color space conversion

### Error Logging
The pipeline provides comprehensive error logging:
- Processing statistics and timing
- Individual image failure details
- Configuration validation errors

## 🧪 Testing

Run basic functionality tests:

```bash
# Test single image processing
python examples/basic_example.py test_images/sample.jpg output_test.jpg

# Test batch processing
python examples/batch_example.py test_images/ output_test/ --verbose
```

## 🤝 Contributing

### Adding New Preprocessing Steps
1. Implement the method in `ImagePreprocessor` class
2. Add configuration parameters to `PreprocessingConfig`
3. Include the step in the processing pipeline
4. Update documentation and examples

### Adding Augmentation Techniques
1. Implement in `MarineDataAugmenter` class
2. Add configuration parameters
3. Include in augmentation pipeline
4. Test with marine-specific scenarios

## 📚 References

- **CLAHE**: Adaptive Histogram Equalization and its Variations
- **Retinex Theory**: Land, E. H. (1977). The Retinex Theory of Color Vision
- **Underwater Image Enhancement**: Comprehensive surveys on underwater image processing
- **Marine Biofouling**: Naval fouling and its impact on maritime operations

## 📋 Recommended Additional Preprocessing Steps

Based on marine fouling detection requirements, consider adding:

1. **Homomorphic Filtering**: For better illumination-reflectance separation
2. **White Balance Correction**: Advanced underwater color correction
3. **Haze Removal**: Dark channel prior for underwater haze
4. **Texture Enhancement**: Gabor filters for fouling texture analysis
5. **Multi-Scale Feature Enhancement**: Pyramid-based detail enhancement

## 📄 License

This project is designed for marine fouling detection research and naval applications. Please ensure compliance with relevant regulations when processing sensitive maritime data.

---

**For questions, issues, or contributions, please refer to the project documentation or contact the development team.**